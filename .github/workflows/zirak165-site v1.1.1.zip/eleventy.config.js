// پیکربندی Eleventy: شورت‌کدها، مجموعه‌ها و نسخهٔ آفلاین
import path from "node:path";

const PREVIEW = process.env.PREVIEW === "1";
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

export default function (cfg) {
  cfg.addPassthroughCopy({ "src/assets": "assets" });
  cfg.addPassthroughCopy({ "node_modules/vazirmatn/fonts/webfonts": "assets/fonts" });

  cfg.addCollection("lessons", (api) => api.getFilteredByGlob("src/content/lessons/*.md").sort((a, b) => b.date - a.date));
  cfg.addCollection("projects", (api) => api.getFilteredByGlob("src/content/projects/*.md").sort((a, b) => b.date - a.date));
  cfg.addFilter("fa", (n) => String(n).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[d]));
  const CATS = { deen: "علوم دینی", lang: "زبان‌ها", daily: "سؤال‌های روزمره", mind: "هوش و موفقیت" };
  cfg.addFilter("head", (a, n) => a.slice(0, n));
  cfg.addFilter("catName", (k) => CATS[k] || "");
  cfg.addFilter("dateFa", (d) => new Intl.DateTimeFormat("fa-AF", { dateStyle: "long", timeZone: "UTC" }).format(d));

  // انیمیشن عدد، درجه (حلقه) و دماسنج
  cfg.addShortcode("counter", (v, label = "") =>
    `<div class="stat"><b class="counter" data-to="${esc(v)}">0</b><span>${esc(label)}</span></div>`);
  cfg.addShortcode("ring", (pct, label = "") =>
    `<div class="stat"><svg class="ring" viewBox="0 0 36 36" data-pct="${esc(pct)}" role="img" aria-label="${esc(label)} ${esc(pct)}%"><circle class="bg" cx="18" cy="18" r="15.9"/><circle class="fg" cx="18" cy="18" r="15.9" pathLength="100"/><text x="18" y="20.5" text-anchor="middle" class="counter" data-to="${esc(pct)}" data-suffix="%">0%</text></svg><span>${esc(label)}</span></div>`);
  cfg.addShortcode("thermo", (pct, label = "") =>
    `<div class="stat"><div class="thermo" data-pct="${esc(pct)}" role="img" aria-label="${esc(label)} ${esc(pct)}%"><i></i></div><span>${esc(label)} <b class="counter" data-to="${esc(pct)}" data-suffix="%">0%</b></span></div>`);

  if (PREVIEW) {
    // لینک‌های مطلق → نسبی، تا روی file:// کار کنند + نشان پیش‌نمایش
    cfg.addTransform("offline", function (content) {
      if (!(this.page.outputPath || "").endsWith(".html")) return content;
      const up = path.relative(path.dirname(this.page.outputPath), "_preview") || ".";
      const fix = (p) => up + "/" + p;
      return content
        .replace(/(href|src)="\/([^"]*)"/g, (m, a, p) => {
          const target = p === "" || p.endsWith("/") ? p + "index.html" : p;
          return `${a}="${fix(target)}"`;
        })
        .replace("</body>", '<div style="position:fixed;bottom:8px;left:8px;background:#e8710a;color:#fff;padding:2px 10px;border-radius:99px;font-size:12px;z-index:99">پیش‌نمایش آفلاین</div></body>');
    });
  }

  return { dir: { input: "src", includes: "../templates", data: "_data", output: PREVIEW ? "_preview" : "_site" }, markdownTemplateEngine: "njk", htmlTemplateEngine: "njk" };
}
