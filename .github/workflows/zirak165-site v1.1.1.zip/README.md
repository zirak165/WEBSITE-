# سایت شخصی زیرک (Eleventy)
- `npm ci && npm run build` → `_site` (سایت) و `_preview` (نسخهٔ آفلاین برای بررسی؛ روی file:// باز می‌شود)
- محتوا: `src/content/lessons` و `src/content/projects` (هر فایل `.md`، فیلدهای title/cat/summary/date)
- شورت‌کدها: `{% counter 14, "زبان" %}` ، `{% ring 80, "برچسب" %}` ، `{% thermo 60, "برچسب" %}`
- داده‌ها: `src/_data/` (site.json، about.json، i18n.json)
- صفحهٔ `/chat/`: رمزدار، noindex و دارای CSP. کلیدها فقط رمزشده در مرورگر می‌مانند و داخل کد نیستند.
- انتشار: Settings → Pages → Source: GitHub Actions، سپس push روی main.
