// ساخت نسخهٔ آفلاین (_preview) با لینک‌های نسبی
import { spawnSync } from "node:child_process";
const r = spawnSync("npx", ["eleventy"], { stdio: "inherit", env: { ...process.env, PREVIEW: "1" } });
process.exit(r.status ?? 1);
