---
title: وب‌سایت شخصی
cat: mind
summary: همین سایت، با Eleventy و GitHub Pages.
date: 2026-11-01
---
این سایت با Eleventy ساخته شده و با GitHub Actions منتشر می‌شود.
