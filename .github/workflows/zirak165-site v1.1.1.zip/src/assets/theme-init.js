// اعمال تم و زبان پیش از رندر، تا پرش دیده نشود
(function () {
  var t = localStorage.getItem("theme") || "auto";
  var l = localStorage.getItem("lang") || "fa";
  var d = document.documentElement;
  d.setAttribute("data-theme", t);
  d.setAttribute("lang", l);
  d.setAttribute("dir", l === "en" ? "ltr" : "rtl");
})();
