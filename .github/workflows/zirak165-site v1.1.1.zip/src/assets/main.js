(function () {
  var root = document.documentElement;
  var i18n = JSON.parse(document.getElementById("i18n").textContent);

  function setLang(l) {
    localStorage.setItem("lang", l);
    var s = i18n[l] || i18n.fa;
    root.lang = l; root.dir = s.dir;
    document.querySelectorAll("[data-i18n]").forEach(function (e) {
      var v = s[e.getAttribute("data-i18n")]; if (v) e.textContent = v;
    });
    document.querySelectorAll("[data-lang]").forEach(function (b) {
      b.setAttribute("aria-pressed", b.getAttribute("data-lang") === l);
    });
  }
  document.querySelectorAll("[data-lang]").forEach(function (b) {
    b.addEventListener("click", function () { setLang(b.getAttribute("data-lang")); });
  });
  setLang(localStorage.getItem("lang") || "fa");

  // تم: auto → light → dark
  var order = ["auto", "light", "dark"];
  function applyBar() {
    var dark = root.getAttribute("data-theme") === "dark" ||
      (root.getAttribute("data-theme") === "auto" && matchMedia("(prefers-color-scheme: dark)").matches);
    var m = document.querySelector('meta[name="theme-color"]');
    if (m) m.content = dark ? "#131314" : "#F0F4F9";
  }
  document.getElementById("themeBtn").addEventListener("click", function () {
    var n = order[(order.indexOf(root.getAttribute("data-theme")) + 1) % 3];
    root.setAttribute("data-theme", n); localStorage.setItem("theme", n); applyBar();
  });
  applyBar();

  // انیمیشن عدد، حلقه و دماسنج
  var reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  function run(el) {
    if (el.dataset.done) return; el.dataset.done = 1;
    el.querySelectorAll(".counter").forEach(function (c) {
      var to = +c.dataset.to, suf = c.dataset.suffix || "", t0 = null;
      function step(t) {
        t0 = t0 || t; var p = reduce ? 1 : Math.min((t - t0) / 1200, 1);
        c.textContent = Math.round(to * p).toLocaleString("en") + suf;
        if (p < 1) requestAnimationFrame(step);
      }
      requestAnimationFrame(step);
    });
    var r = el.querySelector(".ring .fg"); if (r) r.style.strokeDashoffset = 100 - el.querySelector(".ring").dataset.pct;
    var th = el.querySelector(".thermo i"); if (th) th.style.height = el.querySelector(".thermo").dataset.pct + "%";
  }
  var io = "IntersectionObserver" in window ? new IntersectionObserver(function (es) {
    es.forEach(function (e) { if (e.isIntersecting) { run(e.target); io.unobserve(e.target); } });
  }, { threshold: .3 }) : null;
  document.querySelectorAll(".stat").forEach(function (s) { io ? io.observe(s) : run(s); });
})();
