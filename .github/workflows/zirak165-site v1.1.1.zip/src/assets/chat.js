"use strict";
const $=id=>document.getElementById(id);
const enc=new TextEncoder(),dec=new TextDecoder();
const b64=u=>btoa(String.fromCharCode(...u));
const unb64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
const VAULT="zirak_vault_v1";
const DEFAULTS={orKey:"",ghToken:"",model:"",temp:1,maxTok:0,
  models:"openai/gpt-4o-mini\nanthropic/claude-3.5-sonnet\ngoogle/gemini-2.0-flash-001",
  sys:"تو دستیار دوستانه‌ی «زیرک» هستی. همیشه به فارسی و با احترام پاسخ بده."};
let cryptoKey=null,salt=null,S={...DEFAULTS},history=[],cur=null,curDir="",abortCtl=null;

/* ---------- vault ---------- */
async function derive(pw,salt){
  const km=await crypto.subtle.importKey("raw",enc.encode(pw),"PBKDF2",false,["deriveKey"]);
  return crypto.subtle.deriveKey({name:"PBKDF2",salt,iterations:250000,hash:"SHA-256"},km,{name:"AES-GCM",length:256},false,["encrypt","decrypt"]);
}
async function persist(){
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const ct=new Uint8Array(await crypto.subtle.encrypt({name:"AES-GCM",iv},cryptoKey,enc.encode(JSON.stringify(S))));
  localStorage.setItem(VAULT,JSON.stringify({salt:b64(salt),iv:b64(iv),data:b64(ct)}));
}
const stored=()=>{try{return JSON.parse(localStorage.getItem(VAULT))}catch{return null}};

function initLock(){
  const v=stored();
  if(v){$("lockTitle").textContent="ورود";$("lockHint").textContent="رمز عبورت را وارد کن.";}
  else{$("lockTitle").textContent="ساخت رمز عبور";$("lockHint").textContent="اولین ورود: یک رمز قوی بساز. این رمز کلیدهایت را رمزنگاری می‌کند و قابل بازیابی نیست.";$("pw2").classList.remove("hide");}
}
async function unlock(){
  $("lockErr").textContent="";
  const pw=$("pw").value,v=stored();
  try{
    if(!v){
      if(pw.length<8)return $("lockErr").textContent="رمز دست‌کم ۸ نویسه باشد.";
      if(pw!==$("pw2").value)return $("lockErr").textContent="دو رمز یکسان نیست.";
      salt=crypto.getRandomValues(new Uint8Array(16));
      cryptoKey=await derive(pw,salt);await persist();
    }else{
      salt=unb64(v.salt);cryptoKey=await derive(pw,salt);
      const pt=await crypto.subtle.decrypt({name:"AES-GCM",iv:unb64(v.iv)},cryptoKey,unb64(v.data));
      S={...DEFAULTS,...JSON.parse(dec.decode(pt))};
    }
  }catch{cryptoKey=null;return $("lockErr").textContent="رمز اشتباه است.";}
  $("pw").value=$("pw2").value="";$("lock").classList.add("hide");
  fillModels();loadRepos();
}
function lockNow(){location.reload();}

/* ---------- settings ---------- */
function fillModels(){
  const list=S.models.split("\n").map(s=>s.trim()).filter(Boolean);
  if(S.model&&!list.includes(S.model))list.unshift(S.model);
  $("model").innerHTML="";list.forEach(m=>{const o=document.createElement("option");o.value=o.textContent=m;$("model").appendChild(o);});
  if(S.model)$("model").value=S.model;
}
function openSet(){
  $("orKey").value=S.orKey;$("ghTok").value=S.ghToken;$("models").value=S.models;$("sys").value=S.sys;
  $("defModel").value=S.model||$("model").value||"";$("temp").value=S.temp;$("maxTok").value=S.maxTok;
  $("pwCur").value=$("pwNew").value=$("pwNew2").value="";$("setMsg").textContent="";
  $("setOv").classList.remove("hide");
}
async function saveSet(){
  S.orKey=$("orKey").value.trim();S.ghToken=$("ghTok").value.trim();S.models=$("models").value;S.sys=$("sys").value;
  S.model=$("defModel").value.trim();
  const t=parseFloat($("temp").value);S.temp=isNaN(t)?1:Math.min(2,Math.max(0,t));
  const mt=parseInt($("maxTok").value,10);S.maxTok=isNaN(mt)||mt<0?0:mt;
  await persist();fillModels();$("setOv").classList.add("hide");loadRepos();
}
/* تغییر رمز: رمز فعلی را با خود vault راستی‌آزمایی می‌کند */
async function changePw(){
  const m=$("setMsg");m.textContent="";
  const cur=$("pwCur").value,n1=$("pwNew").value,n2=$("pwNew2").value,v=stored();
  if(n1.length<8)return m.textContent="رمز تازه دست‌کم ۸ نویسه باشد.";
  if(n1!==n2)return m.textContent="دو رمز تازه یکسان نیست.";
  try{const k=await derive(cur,unb64(v.salt));await crypto.subtle.decrypt({name:"AES-GCM",iv:unb64(v.iv)},k,unb64(v.data));}
  catch{return m.textContent="رمز فعلی اشتباه است.";}
  salt=crypto.getRandomValues(new Uint8Array(16));cryptoKey=await derive(n1,salt);await persist();
  $("pwCur").value=$("pwNew").value=$("pwNew2").value="";m.textContent="رمز تغییر کرد ✔";
}
function resetAll(){
  if(!confirm("همهٔ داده‌ها (رمز، کلیدها و تنظیمات) از این مرورگر پاک شود؟"))return;
  localStorage.removeItem(VAULT);location.reload();
}
async function fetchModels(){
  const m=$("setMsg");m.textContent="در حال دریافت فهرست مدل‌ها…";
  try{
    const r=await fetch("https://openrouter.ai/api/v1/models");if(!r.ok)throw new Error(r.status);
    const j=await r.json();const dl=$("modelList");dl.innerHTML="";
    j.data.map(x=>x.id).sort().forEach(id=>{const o=document.createElement("option");o.value=id;dl.appendChild(o);});
    m.textContent=j.data.length+" مدل دریافت شد؛ در کادر «مدل پیش‌فرض» جست‌وجو کن.";
  }catch(e){m.textContent="خطا در دریافت فهرست: "+e.message;}
}
function addFav(){
  const id=$("defModel").value.trim();if(!id)return;
  const l=$("models").value.split("\n").map(s=>s.trim()).filter(Boolean);
  if(!l.includes(id))l.push(id);$("models").value=l.join("\n");
}
function toggleShow(id){const e=$(id);e.type=e.type==="password"?"text":"password";}

/* ---------- chat ---------- */
function addMsg(role,text){
  const d=document.createElement("div");d.className="m "+(role==="user"?"u":"a");d.textContent=text;
  $("msgs").appendChild(d);$("msgs").scrollTop=1e9;return d;
}
async function send(){
  const t=$("inp").value.trim();if(!t)return;
  if(!S.orKey){addMsg("assistant","ابتدا کلید OpenRouter را در تنظیمات وارد کن.");return;}
  $("inp").value="";addMsg("user",t);history.push({role:"user",content:t});
  let sys=S.sys;
  if($("ctx").checked&&cur){sys+=`\n\nفایل باز‌شده (${cur.repo}/${cur.path}):\n\`\`\`\n${$("editor").value.slice(0,40000)}\n\`\`\``;}
  const out=addMsg("assistant","…");let full="";
  abortCtl=new AbortController();
  try{
    const r=await fetch("https://openrouter.ai/api/v1/chat/completions",{method:"POST",signal:abortCtl.signal,
      headers:{"Authorization":"Bearer "+S.orKey,"Content-Type":"application/json"},
      body:JSON.stringify({model:$("model").value,stream:true,temperature:S.temp,...(S.maxTok>0?{max_tokens:S.maxTok}:{}),messages:[{role:"system",content:sys},...history]})});
    if(!r.ok)throw new Error(r.status+" "+(await r.text()).slice(0,300));
    const rd=r.body.getReader();let buf="";
    for(;;){
      const {done,value}=await rd.read();if(done)break;
      buf+=dec.decode(value,{stream:true});
      let i;while((i=buf.indexOf("\n"))>=0){
        const line=buf.slice(0,i).trim();buf=buf.slice(i+1);
        if(!line.startsWith("data:"))continue;
        const p=line.slice(5).trim();if(p==="[DONE]")continue;
        try{const c=JSON.parse(p).choices?.[0]?.delta?.content;if(c){full+=c;out.textContent=full;$("msgs").scrollTop=1e9;}}catch{}
      }
    }
    history.push({role:"assistant",content:full});
  }catch(e){out.textContent="خطا: "+e.message;history.pop();}
}

/* ---------- github ---------- */
async function gh(path,opt={}){
  if(!S.ghToken)throw new Error("توکن گیت‌هاب در تنظیمات وارد نشده است.");
  const r=await fetch("https://api.github.com"+path,{...opt,headers:{"Authorization":"Bearer "+S.ghToken,"Accept":"application/vnd.github+json","X-GitHub-Api-Version":"2022-11-28",...(opt.body?{"Content-Type":"application/json"}:{})}});
  const j=await r.json().catch(()=>({}));
  if(!r.ok)throw new Error(r.status+" "+(j.message||""));
  return j;
}
const stat=m=>$("ghStat").textContent=m;
const ep=p=>p.split("/").map(encodeURIComponent).join("/");
async function loadRepos(){
  if(!S.ghToken)return;
  try{
    const l=await gh("/user/repos?per_page=100&sort=updated");
    $("repo").innerHTML='<option value="">— مخزن را انتخاب کن —</option>';
    l.forEach(x=>{const o=document.createElement("option");o.value=x.full_name;o.textContent=x.full_name+(x.private?" 🔒":"");$("repo").appendChild(o);});
    stat("مخزن‌ها بارگذاری شد.");
  }catch(e){stat("خطا: "+e.message);}
}
async function browse(dir){
  const repo=$("repo").value;if(!repo)return;
  try{
    const l=await gh(`/repos/${repo}/contents/${ep(dir)}`);
    curDir=dir;$("path").textContent="/"+dir;
    const box=$("files");box.innerHTML="";
    if(dir){const up=document.createElement("div");up.textContent="⬆ ..";up.onclick=()=>browse(dir.split("/").slice(0,-1).join("/"));box.appendChild(up);}
    (Array.isArray(l)?l:[l]).sort((a,b)=>(a.type===b.type?a.name.localeCompare(b.name):a.type==="dir"?-1:1)).forEach(f=>{
      const d=document.createElement("div");d.textContent=(f.type==="dir"?"📁 ":"📄 ")+f.name;
      d.onclick=()=>f.type==="dir"?browse(f.path):openFile(f.path);box.appendChild(d);
    });
  }catch(e){stat("خطا: "+e.message);}
}
async function openFile(path){
  const repo=$("repo").value;
  try{
    const f=await gh(`/repos/${repo}/contents/${ep(path)}`);
    if(f.encoding!=="base64"){return stat("این فایل قابل نمایش نیست.");}
    $("editor").value=dec.decode(unb64(f.content.replace(/\n/g,"")));
    cur={repo,path,sha:f.sha};$("commitMsg").value="Update "+path;stat("باز شد: "+path);
  }catch(e){stat("خطا: "+e.message);}
}
async function saveFile(){
  if(!cur)return stat("اول یک فایل باز کن یا «فایل جدید» بساز.");
  try{
    const body={message:$("commitMsg").value||"Update "+cur.path,content:b64(enc.encode($("editor").value))};
    if(cur.sha)body.sha=cur.sha;
    const r=await gh(`/repos/${cur.repo}/contents/${ep(cur.path)}`,{method:"PUT",body:JSON.stringify(body)});
    cur.sha=r.content.sha;stat("commit شد ✔");browse(curDir);
  }catch(e){stat("خطا: "+e.message);}
}
function newFile(){
  const repo=$("repo").value;if(!repo)return stat("اول مخزن را انتخاب کن.");
  const p=prompt("مسیر فایل جدید (مثلاً docs/note.md):",curDir?curDir+"/":"");if(!p)return;
  cur={repo,path:p,sha:null};$("editor").value="";$("commitMsg").value="Add "+p;stat("فایل جدید: "+p+" — بعد از نوشتن، ذخیره کن.");
}
async function newIssue(){
  const repo=$("repo").value;if(!repo)return stat("اول مخزن را انتخاب کن.");
  const title=prompt("عنوان issue:");if(!title)return;
  const body=prompt("توضیحات (اختیاری):")||"";
  try{const r=await gh(`/repos/${repo}/issues`,{method:"POST",body:JSON.stringify({title,body})});stat("issue #"+r.number+" ساخته شد.");}
  catch(e){stat("خطا: "+e.message);}
}

/* ---------- wiring ---------- */
$("lockBtn").onclick=unlock;
$("pw").onkeydown=$("pw2").onkeydown=e=>{if(e.key==="Enter")unlock();};
$("btnSet").onclick=openSet;$("setSave").onclick=saveSet;$("setClose").onclick=()=>$("setOv").classList.add("hide");
$("btnOut").onclick=lockNow;
$("pwChange").onclick=changePw;$("resetAll").onclick=resetAll;$("fetchModels").onclick=fetchModels;$("addFav").onclick=addFav;
$("showOr").onclick=()=>toggleShow("orKey");$("showGh").onclick=()=>toggleShow("ghTok");
$("model").onchange=async()=>{S.model=$("model").value;await persist();};
$("btnClr").onclick=()=>{history=[];$("msgs").innerHTML="";};
$("btnSend").onclick=send;
$("inp").onkeydown=e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send();}};
$("repo").onchange=()=>{cur=null;$("editor").value="";browse("");};
$("btnSave").onclick=saveFile;$("btnNew").onclick=newFile;$("btnIssue").onclick=newIssue;
initLock();
